package com.example.astralecho.item;

import com.example.astralecho.entity.AstralEntities;
import com.example.astralecho.sound.AstralSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class StarfallTotemItem extends Item {
    public StarfallTotemItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.sidedSuccess(stack, true);
        if (!(level instanceof ServerLevel server) || !player.level().dimension().equals(GroveSigilItem.ASTRAL_GROVE)) {
            player.displayClientMessage(Component.literal("The Starfall Totem only answers in the Astral Grove."), true);
            return InteractionResultHolder.fail(stack);
        }
        if (!server.getEntitiesOfClass(com.example.astralecho.entity.CelestialDevourer.class,
                player.getBoundingBox().inflate(128)).isEmpty()) {
            player.displayClientMessage(Component.literal("The Devourer already stalks this grove..."), true);
            return InteractionResultHolder.fail(stack);
        }
        Vec3 look = player.getLookAngle();
        double x = player.getX() + look.x * 7.0;
        double z = player.getZ() + look.z * 7.0;
        double y = server.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                net.minecraft.core.BlockPos.containing(x, player.getY(), z).getX(),
                net.minecraft.core.BlockPos.containing(x, player.getY(), z).getZ());
        var boss = AstralEntities.CELESTIAL_DEVOURER.get().create(server);
        if (boss == null) return InteractionResultHolder.fail(stack);
        boss.moveTo(x, y + 1, z, player.getYRot(), 0);
        server.sendParticles(ParticleTypes.REVERSE_PORTAL, x, y + 1.3, z, 100, 2.5, 2.0, 2.5, 0.12);
        server.sendParticles(ParticleTypes.EXPLOSION_EMITTER, x, y + 1.2, z, 1, 0, 0, 0, 0);
        server.playSound(null, player.blockPosition(), AstralSounds.ASTRAL_BURST.get(), SoundSource.HOSTILE, 2.2F, 0.45F);
        server.addFreshEntity(boss);
        stack.shrink(1);
        player.getCooldowns().addCooldown(this, 20 * 5);
        server.getPlayers(p -> p.distanceToSqr(x, y, z) < 96 * 96).forEach(p -> p.displayClientMessage(
                Component.literal("THE CELESTIAL DEVOURER HAS AWAKENED!"), true));
        return InteractionResultHolder.success(stack);
    }
}
