package com.example.astralecho.sound;

import com.example.astralecho.AstralEcho;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class AstralSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, AstralEcho.MOD_ID);
    public static final RegistryObject<SoundEvent> ASTRAL_BURST = SOUNDS.register("astral_burst",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(AstralEcho.MOD_ID, "astral_burst")));
    public static final RegistryObject<SoundEvent> WISP_AMBIENT = SOUNDS.register("wisp_ambient",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(AstralEcho.MOD_ID, "wisp_ambient")));
    public static final RegistryObject<SoundEvent> GROVE_AMBIENCE = SOUNDS.register("grove_ambience",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(AstralEcho.MOD_ID, "grove_ambience")));
    public static final RegistryObject<SoundEvent> MUSIC_DISC_STARLIGHT = SOUNDS.register("music_disc_starlight",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(AstralEcho.MOD_ID, "music_disc_starlight")));
    public static final RegistryObject<SoundEvent> MUSIC_DISC_DEVOURER = SOUNDS.register("music_disc_devourer",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(AstralEcho.MOD_ID, "music_disc_devourer")));
    private AstralSounds() {}
}
